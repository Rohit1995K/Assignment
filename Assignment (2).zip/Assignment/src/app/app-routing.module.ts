import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Full_ROUTES } from './shared/routes/full-layout.routes';
import { FullLayoutComponent } from './layouts/full/full-layout.component';

const routes: Routes = [
  { path: '', component: FullLayoutComponent, data: { title: 'full Views' }, children: Full_ROUTES, canActivate: [] },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
