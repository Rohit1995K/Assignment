import { Routes, RouterModule } from '@angular/router';

// Route for content layout with sidebar, navbar and footer.

// tslint:disable-next-line:variable-name
export const  Full_ROUTES: Routes = [
  {
    path: '',
    loadChildren: './user/user.module#UserModule'
  },
  {
    path: 'user',
    loadChildren: './user/user.module#UserModule'
  }
];
