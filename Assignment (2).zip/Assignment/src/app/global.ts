
'use strict';

export const App_Url: string = "http://127.0.0.1:8000/";