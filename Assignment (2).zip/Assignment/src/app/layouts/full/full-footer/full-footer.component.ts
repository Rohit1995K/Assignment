import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-full-footer',
  templateUrl: './full-footer.component.html',
  styleUrls: ['./full-footer.component.scss']
})
export class FullFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
