import { Component, OnInit} from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { CommonService } from './../../common.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})

export class UserListComponent implements OnInit {

  myForm: FormGroup;
  closeResult = '';

  public dataSource = [];
  public info = [];
  constructor(
    private modalService: NgbModal,
    private commonService: CommonService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {
    this.getAllRecords();
  }

  public getAllRecords(): any {
    this.commonService.getUserList()
    .subscribe(resp => {
      this.dataSource = resp.data;
    });
  }

  addNew(content) {
    this.modalService.open(content, { size: 'sm' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });

    this.myForm = this.formBuilder.group({
      fname: new FormControl('', [Validators.required]),
      lname: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required]),
    }, { updateOn: 'change' });

  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }


  public deleteRecord(index): any {
    console.log(this.dataSource);
    this.dataSource.splice(index, 1);
    console.log(this.dataSource);
  }

  public editRecord(content, index): any {
    this.modalService.open(content, { size: 'sm' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  public onSubmit() {
    this.info = this.myForm.value;
    this.dataSource.push(this.info);

    this.myForm.reset();

  }

}

