import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {UserListComponent} from './user-list/user-list.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import {ProfilePageComponent} from './profile-page/profile-page.component';


const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                component: DashboardComponent,
                canActivate: [],
                data: {
                    title: 'dashboard'
                }
            },
            {
                path: 'profile',
                component: ProfilePageComponent,
                canActivate: [],
                data: {
                    title: 'Profile'
                }
            },
            {
                path: 'userlist',
                component: UserListComponent,
                canActivate: [],
                data: {
                    title: 'List'
                }
            },
        ]
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    providers: [
    ],
    exports: [RouterModule],
})
export class UserRoutingModule {}

export const UserComponentList = [
    DashboardComponent,
    ProfilePageComponent,
    UserListComponent,
];
