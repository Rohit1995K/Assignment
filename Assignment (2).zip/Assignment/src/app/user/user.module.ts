import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {UserRoutingModule, UserComponentList} from './user-routing.module';
import { FormGroup, FormControl, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
    imports: [
        CommonModule,
        UserRoutingModule,
        FormsModule,
        ReactiveFormsModule
    ],
    declarations: [
        UserComponentList
    ],
    providers: [
    ]
})

export class UserModule {  }
